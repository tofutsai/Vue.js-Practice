<template>
    <div>
        DOCS{{ vmDocTransfer }}
    </div>
</template>

<script>
import {mapGetters, mapActions, mapState} from 'vuex'
export default {
    data(){
        return{
            tmpValue:"",
        };
    },
    components:{

    },
    watch:{

    },
    computed:{
        ...mapState("docs",["vmDocTransfer"])
    },
    methods:{
        ...mapActions("docs", ["actSetCategory"])
    },
    created(){
        this.actSetCatrgory();
    }
};
</script>